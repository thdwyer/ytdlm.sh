#!/bin/bash

##########
#
# Project     :
# Started     :
# Author      :
# Module      :
# Description :
#
##########
#
# Pass root password in a script:
# create the file crd in your home directory
# chmod 600 ~/crd
# cat ~/crd | sudo -S <CommandToExecute>
# or:
# sudo -S <<< "<password>" <CommandToExecute>
#
#
#
# start of code here

# List of Youtube urls goes in the following file
urlfile=urls.txt

if [ ! -d ~/YouTube ] ; then md ~/YouTube ; fi
# varfile contains the pasted url from option 1
if [ -f ~/YouTube/varfile ] ; then rm ~/YouTube/varfile ; fi

PwdAuth () {
   pwd=""
   if [ ! -f ~/.crd ] ; then
      while [ -z "${pwd}" ]
      do
         echo "      ┌───────────────────────────────────────────────────────────────────────────────────┐"
         echo "      │  The answer to the following question must be either your password or 'n' for no  │"
         echo "      └───────────────────────────────────────────────────────────────────────────────────┘"
         echo
         read -p "        ===>>> Do you want to save your password to enable auto update of yt-dlp? " pwd
         echo
         read -p "        ===>>> You entered ${pwd}.  Is this correct? (y/n) " ans
         if [ ${ans,,} = y ] && [ ${pwd,,} != n ] ; then
            echo
            echo "        ===>>> Your answer will be saved in the file ~/.crd (Mode 600)" ; sleep 3
         else
            pwd=no
            echo
            echo "      ┌──────────────────────────────────────────────────┐"
            echo "      │ The word 'no' will be saved in your .crd file    │"
            echo "      │ if you change your mind, delete the file ~/.crd  │"
         read -p "      │ and you will go through the auth procedure again │" a
            echo "      └──────────────────────────────────────────────────┘"
            echo
         fi
         echo ${pwd} > ~/.crd ; chmod 600 ~/.crd #; pwd=""
      done
   fi
}

clear

PwdAuth

cd ~/YouTube

ans=N

echo
read -p "Is it time to check the version of yt-dlp? " ans
echo

if [ "${ans}" = "Y" ] || [ "${ans}" = "y" ] ; then
      echo " Checking Version of yt-dlp " ; cat ~/.crd | sudo -S yt-dlp -U ; sleep 3
   else
      echo "Skipping check..." ; sleep 1
fi
#exit 0
clear

# Menu options range is 1 to 9 with 0 as the exit:
MI1="Paste URL"
MI2="List Formats"
MI3="Download Playlist no convert"
MI4="Download Playlist and convert to MP4"
MI5="Download default format file"
MI6="Download and extract High Quality Audio"
MI7="Download extract and convert to MP3"
MI8="Download extract and convert to MP4"
MI9="Download from list in ~/YouTube/urls.txt"
MI0="Exit"

# Header and footer stuff
HEADER="YouTube Download menu"
HEADL=${#HEADER}
PROMPT="Choose an option: "
PROMPL=${#PROMPT}


# Line drawng characters:
topline=" ┌─┐"
sidelin=" │ │"
botline=" └─┘"

# The above as individual characters
tl="┌"
bl="└"
tr="┐"
br="┘"
hl="─"
vl="│"

# get padding value - may not need to use this variable
spaces=$(printf "%*s%s" ${padwidth} '')

# Colour names:
#red='\033[0;41;30m' # inverts background

# Normal colours
black="\e[0;30m"
red="\e[0;31m"
green="\e[0;32m"
yellow="\e[0;33m"
blue="\e[0;34m"
purple="\e[0;35m"
cyan="\e[0;36m"
white="\e[0;37m"

# Highlightedn colours
bblack="\e[1;30m"
rred="\e[1;31m"
ggreen="\e[1;32m"
yyellow="\e[1;33m"
bblue="\e[1;34m"
ppurple="\e[1;35m"
ccyan="\e[1;36m"
wwhite="\e[1;37m"

clear='\e[0m'

#
# Color and string padding Functions
##

Shortln () {
     echo -n "<<" ; printf '=%.0s' {1..40} ; echo ">>"
}

LongLn () {
     echo -n "<<" ; printf '=%.0s' {1..120} ; echo ">>"
}

PadLen(){
     echo -ne "$spaces"
}

ColorGreen(){
	echo -ne $ggreen$1$clear
}
ColorYellow(){
	echo -ne $yyellow$1
}
ColorRed(){
	echo -ne $red$1$clear
}
ColorBlue(){
	echo -ne $bblue$1$clear
}
ColorCyan(){
	echo -ne $ccyan$1$clear
}

# Check that there is a URL to process
NOURL (){
        err=0
        if [  ! -f ~/varfile ] ; then
            tput cup $(( BOXTOP + j )) $(( halfwid - ( PROMPL / 2 ) )) ; echo -ne $rred"${spaces}URL not present. " ; tput el ; sleep 2 ; err=1
        fi
}
# Paste URL
URL (){
        echo -e "$wwhite"
        read -p "  Paste URL: " var ; echo $var > ~/varfile
        echo ""
        echo -e "$yyellow    Got URL: $var"
        echo -e "$wwhite"
        read -p "  Press <Enter>"
}

# List Formats
FMT (){
        # Do some error trapping here
        NOURL
        if [ ${err} == 0 ] ; then
            echo ""
            echo "  Getting Formats for Video: "
            printf "\033c" ; tput reset # Didn't have any effect
            yt-dlp --progress -F $(<~/varfile)
            echo ""
            read -p "Press <Enter>"
        fi
}

# Download Playlist - whatever is the best format
PLS (){
        # Do some error trapping here
        NOURL
        if [ ${err} == 0 ] ; then
            echo""
            yt-dlp --progress -f "bestvideo+bestaudio/best" --yes-playlist -o "~/YouTube/%(playlist)s/%(title)s." $(<~/varfile)
            echo ""
            read -p "Press <Enter>"
        fi
}


# Download Playlist and convert whatever to MP4
PLSMP4 (){
        # Do some error trapping here
        NOURL
        if [ ${err} == 0 ] ; then
            echo ""
            yt-dlp --progress  -f "bestvideo+bestaudio/best" --yes-playlist --recode-video mp4 -o "~/YouTube/%(playlist)s/%(title)s." --embed-chapters $(<~/varfile)
            echo ""
            read -p "Press <Enter>"
        fi
}


# Download the default format video
DFLT (){
        # Do some error trapping here
        NOURL
        if [ ${err} == 0 ] ; then
            echo ""
            yt-dlp --progress $(<~/varfile)
            echo ""
            read -p "Press <Enter>"
        fi
}

# Download and extract High Quality Audio
HiQ (){
        # Do some error trapping here
        NOURL
        if [ ${err} == 0 ] ; then
            echo ""
            yt-dlp --progress --extract-audio $(<~/varfile)
            echo ""
            read -p "Press <Enter>"
        fi
}

# Download, extract and convert to MP3
MP3 (){
        # Do some error trapping here
        NOURL
        if [ ${err} == 0 ] ; then
            echo ""
            yt-dlp --progress -x --audio-format mp3 --extract-audio $(<~/varfile)
            echo ""
            read -p "Press <Enter>"
        fi
}

# Download Video
MP4 (){
        # Do some error trapping here
        NOURL
        if [ ${err} == 0 ] ; then
            echo ""
            yt-dlp --progress -f mp4 $(<~/varfile)
            echo ""
            read -p "Press <Enter>"
        fi
}

URLS () {
        nurl=`grep ^https $urlfile | wc -l`
        for (( url=1 ; url<=$nurl ; url++ ));
              do
                 current=`grep https urls.txt | head -n $url | tail -1` #; echo $current
                 Shortln
                 echo "${current}"
                 Shortln
                 echo ""
                 yt-dlp --progress $current
                 echo ""
                 LongLn
                 echo ""
              done
           echo ""
           read -p "Press <Enter>"
}

# Remove the URL paste file
CLN (){
        if [ -f ~/varfile ] ; then rm ~/varfile ; fi
}


#------------------------------------------------------------------------------
# How to catenate variables and derive the result from a previousley
# defined variable taht is the same as the previousley catenated variable names
# i=1 label=MI line=${label}${i}  string=${!line} length${#string}
#------------------------------------------------------------------------------

count=$(grep "MI[1-9]\=" $0 | wc -l)
err=0
z=0
j=0
a=""

for i in $( seq 1 $count )
do
    line=MI${i}
    STR=${!line}
    STRlen=${#STR}
    if [ $STRlen -lt $z ] ; then
        z=$z # do nothing
    else
        z=$STRlen
    fi
    STRlen=$z
done

menu() {

length=${STRlen}
height=$(tput lines)
width=$(tput cols)
halflen=$(( STRlen / 2 ))
halfwid=$(( $(tput cols) / 2))
padwidth=$(( length + 10 ))

BOXTOP=4
LEFTCOL=$(( halfwid - halflen - 3 ))
RIGHTCOL=$(( LEFTCOL + padwidth + 0 ))

#echo "Width: $width   STRlen: $STRlen  halfwid: $halfwid  halflen: $halflen   Leftcol: $LEFTCOL   Rightcol: $RIGHTCOL   padwdth: $padwidth"; read b

clear

# Print Header text
tput cup 2 $(( halfwid - ( HEADL / 2 ) )) ; printf "$ppurple$HEADER$clear"
# Print top line of Box
# printf $bblue ; tput cup ${BOXTOP} ${LEFTCOL} ; seq -s '*' $(( padwidth + 2 )) | tr -dc '[*\n]' ; printf $clear
printf $bblue ; tput cup ${BOXTOP} ${LEFTCOL} ; printf ${tl} ; for j in $(seq 0 $((padwidth - 2 ))) ; do printf ${hl} ; done ; printf ${tr}${clear}
menuheight=$(( count + 4 ))
i=0

# Print the sides of the menu frame
for i in $( seq 1 $menuheight )
   do
      # Print the left side character {i} lines
      printf $bblue ; tput cup $(( BOXTOP + i )) ${LEFTCOL} ; printf ${vl}${clear}
      if [ $i -ge 2 ] && [ $i -lt $(( menuheight - 1 )) ]; then
           line=MI$(( i -1 )) ; STR=${!line}
          if [ ! -z "$STR" ] ; then
              # Menu option items get printed here
              printf "  $wwhite$(( i - 1 )) $ggreen)  $yyellow${!line}"
              # Prepare a value used to align the choose an option prompt
              # and the selection error prompt
              j=$(( i + 6 ))
          else
              # This prints the Exit option
              tput cup $(( BOXTOP + i + 1 )) ${LEFTCOL} ; printf "${vl}  ${rred}0 ${ggreen})  ${rred}${MI0}"
          fi
   fi
   # Print the right side character {i} lines
   printf $bblue ; tput cup $(( BOXTOP + i )) ${RIGHTCOL} ; printf ${vl} printf $clear
done

#Print the bottom line of the box
# printf $bblue ; tput cup $(( BOXTOP + i + 1 )) ${LEFTCOL} ; seq -s '*' $(( padwidth + 2 )) | tr -dc '[*\n]' ; printf $clear
printf $bblue ; tput cup $(( BOXTOP + i + 1 )) ${LEFTCOL} ; printf ${bl} ; for k in $(seq 0 $((padwidth - 2 ))) ; do printf ${hl} ; done ; printf ${br}${clear}

# Print rompt string below the box and read the selection
# Print Prompt text
tput cup $(( BOXTOP + j )) $(( halfwid - ( PROMPL / 2 ) )) ; printf "$ccyan$PROMPT" ; tput el #; printf $clear

read a
   case $a in
      1) URL    ; menu ;;
      2) FMT    ; menu ;;
      3) PLS    ; menu ;;
      4) PLSMP4 ; menu ;;
      5) DFLT   ; menu ;;
      6) HiQ    ; menu ;;
      7) MP3    ; menu ;;
      8) MP4    ; menu ;;
      9) URLS   ; menu ;;
      0) printf "\033c" ; exit 0 ;;
      *) tput cup $(( BOXTOP + j )) $(( halfwid - ( PROMPL / 2 ) )) ; echo -ne $rred"$spaces   Wrong option." ; tput el ; sleep 2 ; clear ; menu ;;
   esac
}

# Call the menu function
printf "\033c"
menu

# EOF
